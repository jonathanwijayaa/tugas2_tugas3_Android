package com.example.studentmanagerapp

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    private lateinit var adapter: ArrayAdapter<String>
    private lateinit var dataList: ArrayList<String>
    private lateinit var dbHelper: DBHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DBHelper(this)

        val addButton = findViewById<Button>(R.id.buttonAdd)
        val showButton = findViewById<Button>(R.id.buttonShow)
        val editTextName = findViewById<EditText>(R.id.editTextText3)
        val editTextNomor = findViewById<EditText>(R.id.editTextPhone)
        val editTextWarna = findViewById<EditText>(R.id.editWarna)
        val listView = findViewById<ListView>(R.id.listView)

        dataList = ArrayList()
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, dataList)
        listView.adapter = adapter
        listView.setOnItemClickListener {parent, view, position, id ->
            val selectedItem = dataList[position]
            Toast.makeText(this, "Anda memilih: $selectedItem", Toast.LENGTH_SHORT).show()
        }

        addButton.setOnClickListener {

            val name = editTextName.text.toString()
            val nomor = editTextNomor.text.toString().toIntOrNull()
            val warna = editTextWarna.text.toString()

            if (name.isNotEmpty() && nomor != null && warna.isNotEmpty()) {
                dbHelper.insertData(name, nomor,warna)
                Toast.makeText(this, "Data berhasil ditambahkan", Toast.LENGTH_SHORT).show()
                editTextName.text.clear()
                editTextNomor.text.clear()
                editTextWarna.text.clear()
                loadData()
            } else {
                Toast.makeText(this, "Data gagal ditambahkan", Toast.LENGTH_SHORT).show()
            }
        }

        showButton.setOnClickListener {
            loadData()
        }

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun loadData() {
        dataList.clear()
        val allData = dbHelper.getAllData()
        for (student in allData) {
            dataList.add("${student.id}. ${student.name} - ${student.nomor} - ${student.warna}")
        }
        adapter.notifyDataSetChanged()
}}
