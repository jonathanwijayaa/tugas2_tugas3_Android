package com.example.studentmanagerapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast


data class Student(val id: Int, val name: String, val nomor: Int, val warna: String)


class DBHelper(context: Context) : SQLiteOpenHelper(context, "student_manager.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        val createTableQuery = """
        CREATE TABLE IF NOT EXISTS tugas2 (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            nomor INTEGER NOT NULL,
            warna TEXT NOT NULL
        )
    """.trimIndent()
        db.execSQL(createTableQuery)
    }


    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < newVersion) {
            db?.execSQL("DROP TABLE IF EXISTS tugas2")
            onCreate(db)
        }
    }


    fun insertData(name: String, nomor: Int, warna: String) {
        val db = writableDatabase
        val values = ContentValues().apply {
            put("name", name)
            put("nomor", nomor)
            put("warna", warna)
        }
        db.insert("tugas2", null, values)
        db.close()
    }


    fun getAllData(): List<Student> {
        val dataList = mutableListOf<Student>()
        val db = readableDatabase
        val cursor = db.rawQuery("SELECT * FROM tugas2", null)
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                val name = cursor.getString(cursor.getColumnIndexOrThrow("name"))
                val nomor = cursor.getInt(cursor.getColumnIndexOrThrow("nomor"))
                val warna = cursor.getString(cursor.getColumnIndexOrThrow("warna"))
                dataList.add(Student(id, name, nomor, warna))
            } while (cursor.moveToNext())
        }
        cursor.close()
        db.close()
        return dataList
    }
}