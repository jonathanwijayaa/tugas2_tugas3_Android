package com.example.mynotes.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.mynotes.model.Notes

class NoteViewModel : ViewModel() {
    private val _notes = MutableLiveData<List<Notes>>(emptyList())
    val notes: LiveData<List<Notes>> get() = _notes

    // Mendapatkan semua catatan
    fun getAllNotes(): LiveData<List<Notes>> = notes

    // Menambahkan catatan baru
    fun addNote(note: Notes) {
        val updatedList = _notes.value?.toMutableList() ?: mutableListOf()
        updatedList.add(note)
        _notes.value = updatedList // ✅ Memicu update LiveData
    }

    // Mendapatkan catatan berdasarkan ID
    fun getNoteById(noteId: Int): Notes? {
        return _notes.value?.find { it.id == noteId }
    }

    // Menghapus catatan berdasarkan ID
    fun deleteNote(noteId: Int) {
        _notes.value = _notes.value?.filterNot { it.id == noteId } // ✅ Memicu update LiveData
    }

    // Memperbarui catatan berdasarkan ID
    fun updateNote(updatedNote: Notes) {
        _notes.value = _notes.value?.map { if (it.id == updatedNote.id) updatedNote else it } // ✅ Memicu update LiveData
    }
}
