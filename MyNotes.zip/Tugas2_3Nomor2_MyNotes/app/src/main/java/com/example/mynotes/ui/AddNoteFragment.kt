package com.example.mynotes.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import androidx.activity.addCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.findNavController
import com.example.mynotes.R
import com.example.mynotes.model.Notes
import com.example.mynotes.viewmodel.NoteViewModel

class AddNoteFragment : Fragment() {
    private val noteViewModel: NoteViewModel by activityViewModels()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_add_note, container, false)

        val titleInput = view.findViewById<EditText>(R.id.editTitle)
        val contentInput = view.findViewById<EditText>(R.id.editContent)
        val addButton = view.findViewById<Button>(R.id.btnAddNote)

        addButton.setOnClickListener {
            val title = titleInput.text.toString()
            val content = contentInput.text.toString()
            if (title.isNotEmpty() && content.isNotEmpty()) {
                noteViewModel.addNote(Notes(id, title, content))
                findNavController().navigate(R.id.action_addNoteFragment_to_noteListFragment)
            }
        }
        return view
    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Pastikan fragment ini menggunakan ActionBar
        val activity = activity as? AppCompatActivity
        activity?.supportActionBar?.apply {
            setDisplayHomeAsUpEnabled(true) // Menampilkan tombol back
            setHomeAsUpIndicator(R.drawable.ic_arrow_back) // Pastikan ikon back benar
        }

        // Tangani klik tombol back
        requireActivity().onBackPressedDispatcher.addCallback(viewLifecycleOwner) {
            findNavController().navigateUp()
        }
    }

}
