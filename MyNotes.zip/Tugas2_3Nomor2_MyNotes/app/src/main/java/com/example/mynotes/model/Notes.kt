package com.example.mynotes.model

data class Notes(
    val id: Int,
    val title: String,
    val content: String
)
